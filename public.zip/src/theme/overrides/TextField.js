export default function MuiOutlinedInput(theme) {
  return {
    MuiTextField: {
      styleOverrides: {
        root: {
          margin: 1,
          // padding: 0,
          '& .MuiOutlinedInput-root': {
            '&:hover fieldset': {
              borderColor: 'rgba(0, 0, 0, 0.23)',
            },
            '&.Mui-focused fieldset': {
              borderColor: 'rgba(0, 0, 0, 0.23)',
            },
          },
        },
      },
    },
  };
}
