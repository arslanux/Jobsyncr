export default function Typography(theme) {
  return {
    MuiTypography: {
      styleOverrides: {
        paragraph: {
          marginBottom: theme.spacing(2),
        },
        body1: {
          fontSize: '14px',
          color: theme.palette.grey[600],
        },
        body2: {
          fontSize: '12px',
          color: theme.palette.grey[600],
        },
        h6: {
          fontSize: '16px',
          color: theme.palette.grey[600],
        },
        gutterBottom: {
          marginBottom: theme.spacing(1),
        },
        allVariants: {
          color: '#101828',
        },
      },
    },
  };
}
