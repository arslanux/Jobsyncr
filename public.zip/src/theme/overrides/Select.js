// ----------------------------------------------------------------------

export default function Select(theme) {
  return {
    MuiSelect: {
      styleOverrides: {
        root: {
          borderRadius: '8px',
          width: '207px',
          // //   border: "none",
          // //   borderColor: "#FF7C42",
          // color: "#FF7C42",
          // "&:before": {
          //   borderColor: "#FF7C42",
          // },
        },
      },
    },
  };
}
