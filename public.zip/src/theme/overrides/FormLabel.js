export default function FormLabel(theme) {
  return {
    MuiFormLabel: {
      defaultProps: {
        shrink: false,
      },
      styleOverrides: {
        root: {
          color: theme.palette.text.main,
          // fontWeight: 600,
          // fontSize: "18px",
        },
      },
    },
  };
}
