export default function InputLabel(theme) {
  return {
    MuiInputLabel: {
      defaultProps: {
        // shrink: false,
      },
    },
  };
}
