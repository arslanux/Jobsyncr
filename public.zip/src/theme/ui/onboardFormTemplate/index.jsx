import React from "react";
import Stack from "@mui/material/Stack";
import Typography from "@mui/material/Typography";
import Button from "@mui/material/Button";
import Grid from "@mui/material/Grid";
import Card from "@mui/material/Card";
import Box from "@mui/material/Box";
import Divider from "@mui/material/Divider";

import SaveIcon from "../../../assets/save_icon.svg";
import { useSelector } from "react-redux";

const OnboardFormTemplate = ({
  formTitle,
  formSubtitle,
  form,
  onsubmit,
  isMultiple = false,
  isSubmit = true,
}) => {
  const [formCount, setFormCount] = React.useState(1);

  const onboardUserListDelay = useSelector(
    (state) => state?.onboard?.onboardViewDelay
  );

  return (
    <>
      <Grid container spacing={2}>
        <Grid item md={3} sm={12}>
          <Typography variant="h6" sx={{ color: "text.primary" }}>
            {formTitle}
          </Typography>
          <Typography variant="body2">{formSubtitle}</Typography>
        </Grid>

        <Grid item md={9} sm={12}>
          <Stack gap={2}>
            {[...Array(formCount)].map((_, index) => (
              <Card>
                <Stack direction={"column"} gap={2} margin="24px">
                  <Stack direction={"column"} gap={2}>
                    <Stack>{form}</Stack>
                  </Stack>
                </Stack>
                {isSubmit && (
                  <Box>
                    <Divider />

                    <Box
                      sx={{
                        display: "flex",
                        justifyContent: "flex-end",
                        my: 2,
                        px: 2,
                      }}
                    >
                      <Button
                        variant="contained"
                        startIcon={<img src={SaveIcon} alt={"save"} />}
                        onClick={onsubmit}
                        disabled={onboardUserListDelay === true ? true : false}
                        sx={{color:'white',bgcolor:'primary.main'}}
                      >
                        {onboardUserListDelay === true ? "Loading..." : "Save"}
                      </Button>
                    </Box>
                  </Box>
                )}
              </Card>
            ))}
            {isMultiple && (
              <Box>
                <Button
                  variant="contained"
                  color="info"
                  onClick={() => setFormCount(formCount + 1)}
                >
                  Add more
                </Button>
              </Box>
            )}
          </Stack>
        </Grid>
      </Grid>
      <Divider
        sx={{
          mt: 1,
          mb: 1,
          borderColor: "grey.300",
        }}
      />
    </>
  );
};

export default OnboardFormTemplate;
