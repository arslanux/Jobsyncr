export const configuration = {
  auth: {
    clientId: "02cfdb5a-2c6e-4fa5-9b21-68b7aea544df",
  },
};
