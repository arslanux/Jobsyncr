import { Save } from '@mui/icons-material';
import { Button } from '@mui/material';
import React from 'react';

const Test = () => {
  return (
    <Button variant='contained' startIcon={<Save />}>
      hi
    </Button>
  );
};

export default Test;
