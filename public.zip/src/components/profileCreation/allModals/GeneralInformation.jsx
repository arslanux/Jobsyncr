import React from 'react'
import Modal from '@mui/joy/Modal';
import ModalClose from '@mui/joy/ModalClose';
import ModalDialog from '@mui/joy/ModalDialog';
import DialogTitle from '@mui/joy/DialogTitle';
import DialogContent from '@mui/joy/DialogContent';

const GeneralInformation = () => {
    const [layout, setLayout] = React.useState(undefined);
    return (
        <>
            <Modal open={!!layout} onClose={() => setLayout(undefined)}>
                <ModalDialog layout={layout}>
                    <ModalClose />
                    <DialogTitle>Modal Dialog</DialogTitle>
                    <DialogContent>
                        <div>
                            This is a  modal dialog. Press to
                            close it.
                        </div>
                    </DialogContent>
                </ModalDialog>
            </Modal>
        </>
    )
}

export default GeneralInformation