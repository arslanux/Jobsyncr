import React from 'react'
import Profile from '../../dashboard/profile'
import Profilenew from '../../../components/profileCreation/Profilenew'

const ProfileDashboardnew = () => {
    return (
        <>
            <Profilenew />
        </>
    )
}

export default ProfileDashboardnew