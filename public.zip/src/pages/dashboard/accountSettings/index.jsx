import React, { useEffect, useState } from "react";
import Stack from "@mui/material/Stack";
import Typography from "@mui/material/Typography";
import Chip from "@mui/material/Chip";
import Select from "@mui/material/Select";
import MenuItem from "@mui/material/MenuItem";
import TextField from "@mui/material/TextField";
import FormControl from "@mui/material/FormControl";
import Grid from "@mui/material/Grid";
import OnboardFormTemplate from "../../../theme/ui/onboardFormTemplate";
import Upload from "../../../theme/ui/upload";
import CustomTextField from "../../../theme/ui/TextField";
import {
  Autocomplete,
  Checkbox,
  FormControlLabel,
  FormGroup,
  Switch,
} from "@mui/material";
import DeactivvateProfileModal from "./DeactivateProfileModal";
import CompleteProfile from "./CompleteProfile";
import notify from "../../../utils/Toast";
import { useDispatch, useSelector } from "react-redux";
import { ProfileView } from "../../../redux/onboarding/personalInformation/PersonalInfoAction";
import {
  ReferencesApi,
  activateDeactivateProfileApi,
  changePasswordApi,
} from "../../../config/ApiHandler";

const ChangePassword = ({ passwordchangeHandler, changeinput }) => {
  return (
    <Grid container spacing={3}>
      <Grid item xs={12} md={6}>
        <CustomTextField
          name="current_password"
          value={changeinput?.current_password}
          label={"Current Password"}
          onChange={(e) => {
            passwordchangeHandler(e);
          }}
        />
      </Grid>
      <Grid item xs={12} md={6}>
        <CustomTextField
          label={"New Password"}
          name="new_password"
          value={changeinput?.new_password}
          onChange={(e) => {
            passwordchangeHandler(e);
          }}
        />
      </Grid>
      <Grid item xs={12} md={6}>
        <CustomTextField
          label={"Confirm Password"}
          name="confirm_password"
          value={changeinput?.confirm_password}
          onChange={(e) => {
            passwordchangeHandler(e);
          }}
        />
      </Grid>
    </Grid>
  );
};

const Deactivate = ({ handleOpen, data }) => {
  return (
    <Grid container spacing={3}>
      <Grid item xs={12}>
        {data?.deactivated && (
          <Typography color={"red"}>Your Profile is Deactivated</Typography>
        )}
        <FormGroup>
          <FormControlLabel
            onChange={handleOpen}
            control={
              <Switch
                checked={!data?.deactivated}
                sx={{
                  marginTop: -1,
                }}
              />
            }
            sx={{ alignItems: "flex-start" }}
            label="If you deactivate your Zerozilla International profile, you will no longer be able to get information about the matched jobs, shortlisted jobs."
          />
        </FormGroup>
      </Grid>
    </Grid>
  );
};

const AccountSettings = ({ isProfile = false }) => {
  const [open, setOpen] = useState(false);

  const dispatch = useDispatch();

  const onboardUserList = useSelector(
    (state) => state?.onboard?.onboardViewData?.data
  );

  const [changeinput, setChangeinput] = useState([
    {
      current_password: "",
      new_password: "",
      confirm_password: "",
    },
  ]);



  const passwordchangeHandler = (e) => {
    const { name, value } = e.target;
    setChangeinput((prevState) => ({
      ...prevState,
      [name]: value,
    }));
  };

  const sumbitPasswordHandler = async (e) => {
    e.preventDefault();

    try {
      const updateData = {
        current_password: changeinput?.current_password,
        new_password: changeinput?.new_password,
        confirm_password: changeinput?.confirm_password,
      };
      const response = await changePasswordApi(updateData);
      if (response?.data?.status === true) {
        notify("success", response?.data?.message);
        setChangeinput({
          current_password: "",
          new_password: "",
          confirm_password: "",
        });
      } else {
        notify("error", response?.data?.message);
      }
      return response;
    } catch (error) {
      notify("error", "An error occurred while submitting the reference.");
    }
  };
  const handleClose = () => setOpen(false);

  const handleOpen = () => setOpen(true);

  const activateDeactivateHandler = async (value) => {
    
    try {
      const response = await activateDeactivateProfileApi({ status: value });
      if (response?.data?.status === true) {
        notify("success", response?.data?.message);
        dispatch(ProfileView());
        handleClose();
      } else {
        notify("error", response?.data?.message);
      }
      return response;
    } catch (error) {
      notify("error", "An error occurred while submitting.");
    }
  };

  useEffect(() => {
    dispatch(ProfileView());
  }, []);

  return (
    <Stack gap={2} mt={7}>
      {!isProfile && (
        <Stack
          direction={"row"}
          alignItems={"center"}
          justifyContent={"space-between"}
        >
          <Stack direction={"row"} gap={2} alignItems={"center"}>
            <Typography
              variant="h5"
              sx={{
                fontWeight: 600,
                fontSize: "28px",
              }}
            >
              Account Settings
            </Typography>
          </Stack>
        </Stack>
      )}
      <Stack gap={2}>
        <OnboardFormTemplate
          formTitle={"My Profile"}
          form={<CompleteProfile data={onboardUserList?.personalInformation} />}
          isSubmit={false}
        />
        <OnboardFormTemplate
          formTitle={"Change Password"}
          form={
            <ChangePassword
              passwordchangeHandler={passwordchangeHandler}
              changeinput={changeinput}
            />
          }
          onsubmit={sumbitPasswordHandler}
        />
        <OnboardFormTemplate
          formTitle={"Activate/Deactivate my Profile"}
          form={
            <Deactivate
              handleOpen={handleOpen}
              data={onboardUserList?.personalInformation}
            />
          }
          isSubmit={false}
        />
      </Stack>
      <DeactivvateProfileModal
        open={open}
        handleClose={handleClose}
        data={onboardUserList?.personalInformation}
        onChange={activateDeactivateHandler}
      />
    </Stack>
  );
};

export default AccountSettings;
