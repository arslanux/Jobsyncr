import {
  Avatar,
  Box,
  Button,
  Card,
  Divider,
  Stack,
  Typography,
} from "@mui/material";
import React from "react";
import CircleProgress from "../../../theme/ui/CircleProgress";
import RightArrowIcon from "../../../assets/right_arrow.svg";
import { useNavigate } from "react-router-dom";

const CompleteProfile = ({ currentStep = 1, data }) => {
  const navigate = useNavigate();

  return (
    <Card>
      <Stack direction={"column"} gap={2} margin="24px">
        <Stack
          direction={"column"}
          gap={2}
          sx={{ display: { xs: "none", md: "block" } }}
        >
          <Stack>
            <Stack
              direction={"row"}
              gap={2}
              alignItems={"center"}
              justifyContent={"space-between"}
              px={2}
            >
              <Stack direction={"row"} gap={2} alignItems={"center"}>
                <Avatar
                  alt="Remy Sharp"
                  src={data?.profile_pic}
                  sx={{ width: 64, height: 64 }}
                />
                <Stack direction={"column"} gap={0.5}>
                  {!data?.is_profile_completed ? (
                    <Typography
                      variant="h6"
                      sx={{ color: "text.primary", fontWeight: 600 }}
                    >
                      Your Profile is incomplete!
                    </Typography>
                  ) : (
                    <Typography
                      variant="h6"
                      sx={{ color: "text.primary", fontWeight: 600 }}
                    >
                      Your Profile is complete.
                    </Typography>
                  )}

                  {!data?.is_profile_completed && (
                    <Typography variant="body1" sx={{ color: "text.primary" }}>
                      Complete your profile and get shortlisted for the jobs. It will take <strong>15-20 minutes </strong> to complete your profile.
                    </Typography>
                  )}
                </Stack>
              </Stack>
              <Stack direction={"column"} gap={0.5}>
                <CircleProgress
                  value={data?.profile_completion_percentage}
                  color="#23A455"
                />
              </Stack>
            </Stack>
          </Stack>
        </Stack>
        <Stack
          direction={"column"}
          gap={2}
          sx={{ display: { xs: "block", md: "none" } }}
        >
          <Stack>
            {/* <Stack
              direction={"row"}
              gap={2}
              alignItems={"center"}
              justifyContent={"space-between"}
              px={2}
            > */}
            <Stack direction={"row"} gap={2} alignItems={"center"}>
              <Avatar
                alt="Remy Sharp"
                src={data?.profile_pic}
                sx={{ width: 64, height: 64 }}
              />
              <Stack direction={"row"} gap={0.5}>
                {!data?.is_profile_completed ? (
                  <Typography
                    variant="h6"
                    sx={{ color: "text.primary", fontWeight: 600 }}
                  >
                    Your Profile is incomplete!
                  </Typography>
                ) : (
                  <Typography
                    variant="h6"
                    sx={{ color: "text.primary", fontWeight: 600 }}
                  >
                    Your Profile is complete.
                  </Typography>
                )}
              </Stack>
            </Stack>
            <br />
            <Stack direction={"row"} gap={0.5}>
              <CircleProgress
                value={data?.profile_completion_percentage}
                color="#23A455"
                style={{ height: 50, width: 100 }}
              />
              {!data?.is_profile_completed && (
                <Typography variant="body1" sx={{ color: "text.primary" }}>
                  Complete your profile and get shortlisted for the jobs.It will take 15-20 minutes to complete your profile.
                </Typography>
              )}
            </Stack>
          </Stack>
        </Stack>
        {/* </Stack> */}
      </Stack>
      {!data?.is_profile_completed && (
        <Box>
          <Divider />
          <Box
            sx={{
              display: "flex",
              justifyContent: "flex-end",
              my: 2,
              px: 2,
            }}
          >
            <Button
              variant="contained"
              endIcon={<img src={RightArrowIcon} alt={"save"} />}
              onClick={() => navigate("/employee/onboard")}
              sx={{color:'white'}}
            >
              Complete Profile
            </Button>
          </Box>
        </Box>
      )}
    </Card>
  );
};

export default CompleteProfile;
