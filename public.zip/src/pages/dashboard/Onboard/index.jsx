import React, { useEffect, useState } from "react";
import StepsIndicator from "../../../theme/ui/StepsIndicator";
import PersonalInformationForm from "./PersonalInformationForm";
import EducationalBackgroundForm from "./EducationalBackgroundForm";
import ProfessionalInformation from "./ProfessionalInformation";
import Box from "@mui/material/Box";
import Stack from "@mui/material/Stack";
import { Button } from "@mui/material";
import MiscellaneousInformation from "./MiscellaneousInformation";
import Documents from "./Documents";
import References from "./References";
import JobPreferences from "./JobPreferences";
import AgreeToDisclaimer from "./AgreeToDisclaimer";
import SubmitFormModal from "./SubmitFormModal";
import { useDispatch, useSelector } from "react-redux";
import {
  ProfileView,
  onboardingView,
} from "../../../redux/onboarding/personalInformation/PersonalInfoAction";
import {
  areObjectsEqual,
  arePersonalObjectsEqual,
  compareArraysOfObjects,
} from "../../../utils/utilsfunction";
import NextAlert from "./NextAlert";
import useValidation from "../../../hooks/onboard/validation";
import notify from "../../../utils/Toast";
import { DisclamerApi } from "../../../config/ApiHandler";
import { useNavigate } from "react-router-dom";
import useSaveAllSubmit from "../../../hooks/onboard/useSaveAllSubmit";

const Onboard = ({
  isProfile = false,
  tabCount,
  setTabCount,
  setCompletePercentage,
}) => {
  const dispatch = useDispatch();
  const {
    validateUniversityInfo,
    validateLanguageInfo,
    validateEmploymentBackground,
    validateSkillForm,
    resumeValidation,
    jobpreferenceValidateForm,
    higestDegreeValidation,
  } = useValidation();
  // const userData = useSelector(
  //   (state) => state?.auth?.loginData?.userData?.data?.data?.user_data
  // );

  const {
    generalSubmit,
    contactInfoSubmit,
    socialSubmit,
    bioSubmit,
    universitySubmit,
    highestDegreeSubmit,
    languageSubmit,
    employmentSubmit,
    skillSubmit,
    miscAuthCountriesSubmit,
    miscLincensesSubmit,
    miscProfessionalSubmit,
    miscHonorsSubmit,
    miscPublicationSubmit,
    resumeSubmit,
    otherDocumentSubmit,
    referenceSumbit,
    jobReferencesumbit,
  } = useSaveAllSubmit();
  const [agreedTerms, setAgreedTerms] = useState(false);
  const [disableSubmit, setDisableSubmit] = useState(true);

  const handleAgreeDisclaimer = (value) => {
    setAgreedTerms(value);
    setDisableSubmit(!value);
  };
  const isNonEmpty = (value) => value.trim() !== "";

  const isNumber = (value) => /^\d+$/.test(value);

  const isEmail = (value) => /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(value);

  const userData = JSON.parse(localStorage.getItem("login"));

  const navigate = useNavigate();

  const onboardUserList = useSelector(
    (state) => state?.onboard?.onboardViewData?.data
  );
  const onboardUserListDelay = useSelector(
    (state) => state?.onboard?.onboardViewDelay
  );
  console.log(onboardUserListDelay, "onboardUserListDelay");

  const [step, setStep] = React.useState(1);

  const [open, setOpen] = React.useState(false);
  const [openNextAlert, setOpenNextAlert] = React.useState(false);

  const [personalValidationErrors, setPersonalValidationErrors] = useState({});
  const [contactValidationErrors, setContactValidationErrors] = useState({});
  const [bioValidationErrors, setBioValidationErrors] = useState({});
  const [languageValidationErrors, setLanguageValidationErrors] = useState([]);
  const [educationValidationErrors, setEducationValidationErrors] = useState(
    []
  );
  const [employmentValidationErrors, setEmploymentValidationErrors] = useState(
    []
  );

  const [skillValidationErrors, setSkillValidationErrors] = useState([]);

  const [resumeValidationErrors, setResumeValidationErrors] = useState([]);

  const [prefernceValidationErrors, setPrefernceValidationErrors] = useState(
    {}
  );

  const [oldPersonalInfo, setOldPersonalInfo] = useState({
    prefix: "",
    first_name: "",
    last_name: "",
    middle_name: "",
    bio: "",
    profile_pic: "",
    referral_source_id: 11,
  });
  const [currentFormData, setCurrentFormData] = useState({});
  const [unSavedSection, setUnSavedSection] = useState("");

  const [universityInfo, setUniversityInfo] = useState({
    not_provide_education: true,

    universities: [
      {
        // university_id: null,
        university_name: null,
        // degree_id: null,
        degree_name: null,
        //  major_id: null,
        major_name: null,
        // start_date: null,
        end_date: null,
      },
    ],
  });
  const [miscellaneous, setMiscellaneous] = useState({
    file_url: "",
    Professionalname: "",
    honorAndAwards: [
      {
        title: "",
        description: "",
      },
    ],
    majorPublications: [
      {
        title: "",
        co_authors: [
          {
            name: "Author 1",
          },
        ],
        publication_date: null,
        short_description: "",
      },
    ],
    professionalAchievements: [
      {
        title: "",
        achievement_date: null,
        description: "",
      },
    ],
    professionalAssociations: [{ professional_association_name: "" }],
    certificateAndLicenses: [
      {
        title: "",
        file_url: "",
      },
    ],
    workAuthorizations: [],
  });
  const [universityOldData, setUniversityOldData] = useState({
    not_provide_education: false,

    universities: [
      {
        //  university_id: null,
        university_name: null,
        // degree_id: null,
        degree_name: null,
        //  major_id: null,
        major_name: null,
        // start_date: null,
        end_date: null,
      },
    ],
  });
  const [languageOldData, setLanguageOldData] = useState({
    not_provide_language: false,
    languages: [{ name: "", speak: false, read: false, write: false }],
  });
  const [professtionalOldData, setProfesstionalOldData] = useState([{}]);
  const [skillOldData, setSkillOldData] = useState([{}]);
  const [miscOldData, setMiscOldData] = useState({});
  const [resumeOldData, setResumeOldData] = useState({});
  const [otherDocumentsOldData, setOtherDocumentsOldData] = useState([
    {
      name: "",
      type: "",
      file_url: "",
    },
  ]);
  const [referenceOldData, setReferenceOldData] = useState([{}]);
  const [jobPreferencesOldData, setJobPreferencesOldData] = useState([{}]);
  const [languageInfo, setLanguageInfo] = useState({
    not_provide_language: false,
    languages: [{ language_id: "", speak: false, read: false, write: false }],
  });

  const [profestionalFormData, setProfestionalFormData] = useState({
    section_type: "employement_background",
    employementBackgrounds: [
      {
        job_title_id: "",
        employer_name_id: null,
        start_date: null,
        end_date: null,
        designation_id: null,
        major_accomplishment: "",
        roles_responsibility: "",
        international_experience: false,
        currently_working: false,
      },
    ],
    // "section_type":"skills",
  });

  const [skillFormData, setSkillFormData] = useState({
    section_type: "skills",
    skills: [
      {
        skill_id: null,
        skill_proficiency_id: "",
        experience_id: "",
      },
    ],
  });

  const [resumeData, setResumeData] = useState({ resume_file_url: "" });

  const [profileImg, setProfileImg] = useState("");
  const [otherDocuments, setOtherDocuments] = useState([
    {
      name: "",
      type: "",
      file_url: "",
    },
  ]);

  const handleOpen = () => setOpen(true);
  const handleClose = () => setOpen(false);

  const [referenceinput, setReferenceinput] = useState({
    not_provide_reference: true,
    references: [
      {
        name: "",
        email: "",
        mobile: "",
        relation: "",
      },
    ],
  });

  const [jobpreferenceinput, setJobpreferenceinput] = useState({
    preferredIndustrySector: [],
    preferredExperienceLevel: [],
    preferredEmploymentType: [],
    preferredWorkMode: [],
    desiredJobTitle: [],
    typeOfEmployerSeeking: [],

    min_salary_expectation: "",
    currency: "USD",
    comments: "",
    availability: "",
    contact_availability: "",
  });
  const [highestEducation, setHighestEducation] = useState(null);
  const [highestEducationError, setHighestEducationError] = useState("");

  const selectOnboardComponent = (currentStep) => {
    switch (currentStep) {
      case 1:
        return (
          <PersonalInformationForm
            isProfile={isProfile}
            personalData={onboardUserList?.personalInformation}
            setOldPersonalInfo={setOldPersonalInfo}
            setCurrentFormData={setCurrentFormData}
            currentFormData={currentFormData}
            personalValidationErrors={personalValidationErrors}
            contactValidationErrors={contactValidationErrors}
            personalValidateForm={personalValidateForm}
            contactValidateForm={contactValidateForm}
            bioValidationErrors={bioValidationErrors}
            bioValidateForm={bioValidateForm}
            profileImg={profileImg}
            setProfileImg={setProfileImg}
          />
        );
      case 2:
        return (
          <EducationalBackgroundForm
            isProfile={isProfile}
            personalData={onboardUserList?.personalInformation}
            universityInfo={universityInfo}
            setUniversityInfo={setUniversityInfo}
            languageInfo={languageInfo}
            setLanguageInfo={setLanguageInfo}
            validateUniversityInfo={validateUniversityInfo}
            educationValidationErrors={educationValidationErrors}
            setEducationValidationErrors={setEducationValidationErrors}
            educationData={onboardUserList?.educationalBackground}
            languageValidationErrors={languageValidationErrors}
            validateLanguageInfo={validateLanguageInfo}
            setLanguageValidationErrors={setLanguageValidationErrors}
            setUniversityOldData={setUniversityOldData}
            setLanguageOldData={setLanguageOldData}
            languageOldData={languageOldData}
            universityOldData={universityOldData}
            highestEducation={highestEducation}
            setHighestEducation={setHighestEducation}
            highestEducationError={highestEducationError}
            setHighestEducationError={setHighestEducationError}
            higestDegreeValidation={higestDegreeValidation}
          />
        );
      case 3:
        return (
          <ProfessionalInformation
            isProfile={isProfile}
            personalData={onboardUserList?.personalInformation}
            professionalData={onboardUserList?.professionalInformation}
            employmentValidationErrors={employmentValidationErrors}
            setEmploymentValidationErrors={setEmploymentValidationErrors}
            profestionalFormData={profestionalFormData}
            setProfestionalFormData={setProfestionalFormData}
            validateEmploymentBackground={validateEmploymentBackground}
            skillFormData={skillFormData}
            setSkillFormData={setSkillFormData}
            validateSkillForm={validateSkillForm}
            skillValidationErrors={skillValidationErrors}
            setSkillValidationErrors={setSkillValidationErrors}
            setProfesstionalOldData={setProfesstionalOldData}
            setSkillOldData={setSkillOldData}
          />
        );
      case 4:
        return (
          <MiscellaneousInformation
            isProfile={isProfile}
            personalData={onboardUserList?.personalInformation}
            miscData={onboardUserList?.miscellaneousInformation}
            setMiscOldData={setMiscOldData}
            miscOldData={miscOldData}
            miscellaneous={miscellaneous}
            setMiscellaneous={setMiscellaneous}
          />
        );
      case 5:
        return (
          <Documents
            isProfile={isProfile}
            personalData={onboardUserList?.personalInformation}
            docData={onboardUserList?.documents}
            resumeData={resumeData}
            setResumeData={setResumeData}
            resumeValidation={resumeValidation}
            resumeValidationErrors={resumeValidationErrors}
            setResumeValidationErrors={setResumeValidationErrors}
            otherDocuments={otherDocuments}
            setOtherDocuments={setOtherDocuments}
            resumeOldData={resumeOldData}
            setResumeOldData={setResumeOldData}
            otherDocumentsOldData={otherDocumentsOldData}
            setOtherDocumentsOldData={setOtherDocumentsOldData}
          />
        );
      case 6:
        return (
          <References
            isProfile={isProfile}
            personalData={onboardUserList?.personalInformation}
            referenceinput={referenceinput}
            setReferenceinput={setReferenceinput}
            educationData={onboardUserList?.references}
            setReferenceOldData={setReferenceOldData}
            referenceOldData={referenceOldData}
          />
        );
      case 7:
        return (
          <JobPreferences
            isProfile={isProfile}
            personalData={onboardUserList?.personalInformation}
            referencesData={onboardUserList?.jobPreferences}
            setEmploymentValidationErrors={setEmploymentValidationErrors}
            jobpreferenceinput={jobpreferenceinput}
            setJobpreferenceinput={setJobpreferenceinput}
            jobpreferenceValidateForm={jobpreferenceValidateForm}
            prefernceValidationErrors={prefernceValidationErrors}
            setPrefernceValidationErrors={setPrefernceValidationErrors}
            setJobPreferencesOldData={setJobPreferencesOldData}
            jobPreferencesOldData={jobPreferencesOldData}
          />
        );
      case 8:
        return (
          <AgreeToDisclaimer
            isProfile={isProfile}
            handleAgreeDisclaimer={handleAgreeDisclaimer}
            personalData={onboardUserList?.personalInformation}
          />
        );
      // default:
      //   return <Onboard />;
    }
  };

  useEffect(() => {
    if (isProfile) {
      dispatch(ProfileView());
    } else {
      dispatch(onboardingView());
    }
  }, []);

  const personalValidateForm = () => {
    const errors = {};

    if (!currentFormData.prefix) {
      errors.prefix = "Prefix is required";
    }

    if (!currentFormData.first_name) {
      errors.first_name = "First name is required";
    } else if (!/^[a-zA-Z]+$/.test(currentFormData.first_name)) {
      errors.first_name = "First name should contain only alphabet characters";
    }

    // Validate last name
    if (!currentFormData.last_name) {
      errors.last_name = "Last name is required";
    } else if (!/^[a-zA-Z]+$/.test(currentFormData.last_name)) {
      errors.last_name = "Last name should contain only alphabet characters";
    }

    // Validate professional biography
    // if (!currentFormData.bio) {
    //   errors.bio = "Professional biography is required";
    // }

    // Validate referral source
    // if (!currentFormData.referral_source_id) {
    //   errors.referral_source_id = "Please select a referral source";
    // }

    // Update state with validation errors
    setPersonalValidationErrors(errors);

    // Return true if there are no errors, false otherwise
    return Object.keys(errors).length === 0;
  };

  const contactValidateForm = () => {
    const errors = {};

    // Validate Address Line 1
    // if (!isNonEmpty(currentFormData.address_one)) {
    //   errors.address_one = "Address Line 1 is required";
    // }

    // Validate Country
    if (!currentFormData.country_id) {
      errors.country_id = "Country is required";
    }

    // Validate State/Province
    if (!currentFormData.state_id) {
      errors.state_id = "State/Province is required";
    }

    // Validate City
    if (!currentFormData.city_id) {
      errors.city_id = "City is required";
    }

    // Validate Pincode
    if (!isNonEmpty(currentFormData.pincode)) {
      errors.pincode = "Pincode is required";
    } else if (!isNumber(currentFormData.pincode)) {
      errors.pincode = "Pincode should contain only numbers";
    }

    // Validate Mobile
    // if (!isNonEmpty(currentFormData.mobile)) {
    //   errors.mobile = "Mobile Number is required";
    // } else
    // if (!isNumber(currentFormData.mobile)) {
    //   errors.mobile = "Mobile Number should contain only numbers";
    // }

    //validate phone
    if (currentFormData?.tel_num && !isNumber(currentFormData.tel_num)) {
      errors.tel_num = "Phone Number should contain only numbers";
    }
    // Validate Country Code
    if (!isNonEmpty(currentFormData.mobile_country_code)) {
      errors.mobile_country_code = "Country Code is required";
    }

    // Validate Email
    if (!isNonEmpty(currentFormData.email)) {
      errors.email = "Primary Email is required";
    } else if (!isEmail(currentFormData.email)) {
      errors.email = "Invalid Primary Email format";
    }

    // Set validation errors
    setContactValidationErrors(errors);

    // Return true if there are no errors, false otherwise
    return Object.keys(errors).length === 0;
  };

  const bioValidateForm = () => {
    const errors = {};

    // Validate Address Line 1
    if (!currentFormData?.gender_id) {
      errors.gender_id = "Gender is required";
    }
    if (!currentFormData?.veteran_id) {
      errors.veteran_id = "Veteran is required";
    }
    if (!currentFormData?.disability_id) {
      errors.disability_id = "Disability is required";
    }
    if (!currentFormData?.race_ethnicity_id) {
      errors.race_ethnicity_id = "Race/ Ethnicity is required";
    }

    // Set validation errors
    // setBioValidationErrors(errors);

    // Return true if there are no errors, false otherwise
    return Object.keys(errors).length === 0;
  };

  const nextHandler = () => {
    switch (step) {
      case 1:
        if (
          personalValidateForm() &&
          contactValidateForm()
          // bioValidateForm()
        ) {
          const inSaved = arePersonalObjectsEqual(
            oldPersonalInfo,
            currentFormData
          );
          if (inSaved?.status) {
            return setStep(step + 1);
          } else {
            setUnSavedSection(inSaved?.message);
            return setOpenNextAlert(true);
          }
        } else {
          return notify("error", "Please fill all the required fields");
        }
      case 2:
        if (
          higestDegreeValidation(highestEducation, setHighestEducationError)
        ) {
          if (!areObjectsEqual(universityInfo, universityOldData)) {
            console.log(universityInfo, universityOldData);
            setOpenNextAlert(true);
            return setUnSavedSection("University/ College");
          } else if (
            highestEducation !==
            onboardUserList?.personalInformation?.highest_degree_id
          ) {
            setOpenNextAlert(true);
            return setUnSavedSection("Highest Degree Obtained");
          } else if (!areObjectsEqual(languageInfo, languageOldData)) {
            {
              setOpenNextAlert(true);
              return setUnSavedSection("Language");
            }
          } else return setStep(step + 1);
        } else {
          return notify("error", "Please fill all the required fields");
        }
      case 3: {
        if (
          validateEmploymentBackground(
            profestionalFormData?.employementBackgrounds,
            setEmploymentValidationErrors
          )
          // &&
          // validateSkillForm(skillFormData?.skills, setSkillValidationErrors)
        ) {
          if (
            !compareArraysOfObjects(
              profestionalFormData?.employementBackgrounds,
              professtionalOldData
            )
          ) {
            setOpenNextAlert(true);
            return setUnSavedSection("Employment Background");
          }
          //  else if (
          //   !compareArraysOfObjects(skillFormData?.skills, skillOldData)
          // )

          // {
          //   setOpenNextAlert(true);
          //   return setUnSavedSection("Skills");
          // }
          else return setStep(step + 1);
        } else {
          return notify("error", "Please fill all the required fields");
        }
      }
      case 4: {
        if (
          !compareArraysOfObjects(
            miscOldData?.workAuthorizations,
            miscellaneous?.workAuthorizations
          )
        ) {
          setOpenNextAlert(true);
          return setUnSavedSection("Work Authorizations");
        } else if (
          !compareArraysOfObjects(
            miscOldData?.certificateAndLicenses,
            miscellaneous?.certificateAndLicenses
          )
        ) {
          setOpenNextAlert(true);
          return setUnSavedSection("Certifications and Licenses");
        } else if (
          !compareArraysOfObjects(
            miscOldData?.professionalAssociations,
            miscellaneous?.professionalAssociations
          )
        ) {
          setOpenNextAlert(true);
          return setUnSavedSection("Professional Associations");
        } else if (
          !compareArraysOfObjects(
            miscOldData?.professionalAchievements,
            miscellaneous?.professionalAchievements
          )
        ) {
          setOpenNextAlert(true);
          return setUnSavedSection("Professional Achievement");
        } else if (
          !compareArraysOfObjects(
            miscOldData?.majorPublications,
            miscellaneous?.majorPublications
          )
        ) {
          setOpenNextAlert(true);
          return setUnSavedSection("Major Publications");
        } else if (
          !compareArraysOfObjects(
            miscOldData?.honorAndAwards,
            miscellaneous?.honorAndAwards
          )
        ) {
          setOpenNextAlert(true);
          return setUnSavedSection("Honors & Awards");
        } else {
          return setStep(step + 1);
        }
      }
      case 5: {
        if (
          resumeValidation(
            resumeData?.resume_file_url,
            setResumeValidationErrors
          )
        ) {
          if (!areObjectsEqual(resumeData, resumeOldData)) {
            setOpenNextAlert(true);
            return setUnSavedSection("CV/Resume");
          } else if (
            !compareArraysOfObjects(otherDocuments, otherDocumentsOldData)
          ) {
            setOpenNextAlert(true);
            return setUnSavedSection("Other Documents");
          } else {
            return setStep(step + 1);
          }
        } else {
          return notify("error", "Please fill all the required fields");
        }
      }
      case 6: {
        return setStep(step + 1);
      }

      case 7: {
        if (
          jobpreferenceValidateForm(
            jobpreferenceinput,
            setPrefernceValidationErrors
          )
        ) {
          if (!areObjectsEqual(jobpreferenceinput, jobPreferencesOldData)) {
            setOpenNextAlert(true);
            return setUnSavedSection("Preference List");
          } else return setStep(step + 1);
        } else {
          return notify("error", "Please fill all the required fields");
        }
      }
      default:
        setStep(step + 1);
    }
  };

  const handleDisclaimerSubmit = async (e) => {
    e.preventDefault();
    const data = {
      agree_to_disclaimer: true,
    };
    try {
      const res = await DisclamerApi(data);
      if (res?.data?.status === true) {
        handleClose();
        navigate("/dashboard/Home");
        notify(
          "success",
          "You Have Successfully Created a Profile, Welcome to Zerozilla Executive!"
        );
      } else {
        notify("error", res?.data?.message);
      }
    } catch (error) {
      // Handle the error if needed
      notify("error", error?.response?.data?.message);
    }
  };

  const saveAllHandler = async () => {
    switch (step) {
      case 1:
        if (
          personalValidateForm() &&
          contactValidateForm()
          // bioValidateForm()
        ) {
          await generalSubmit(isProfile, currentFormData, profileImg);
          await contactInfoSubmit(isProfile, currentFormData),
            await socialSubmit(isProfile, currentFormData);
          await bioSubmit(isProfile, currentFormData);
          dispatch(isProfile ? ProfileView() : onboardingView());
          return;
        } else {
          return notify("error", "Please fill required field");
        }
      case 2:
        if (
          higestDegreeValidation(highestEducation, setHighestEducationError)
        ) {
          await universitySubmit(isProfile, universityInfo);
          await highestDegreeSubmit(isProfile, highestEducation);
          await languageSubmit(isProfile, languageInfo);
          dispatch(isProfile ? ProfileView() : onboardingView());
          return;
        } else {
          return notify("error", "Please fill required field");
        }
      case 3:
        if (
          validateEmploymentBackground(
            profestionalFormData?.employementBackgrounds,
            setEmploymentValidationErrors
          )
          // &&
          // validateSkillForm(skillFormData?.skills, setSkillValidationErrors)
        ) {
          await employmentSubmit(isProfile, profestionalFormData);
          await skillSubmit(isProfile, skillFormData);
          dispatch(isProfile ? ProfileView() : onboardingView());
          return;
        } else {
          return notify("error", "Please fill required field");
        }
      case 4:
        await miscAuthCountriesSubmit(isProfile, miscellaneous);
        await miscLincensesSubmit(isProfile, miscellaneous);
        await miscProfessionalSubmit(isProfile, miscellaneous);
        await miscHonorsSubmit(isProfile, miscellaneous);
        await miscPublicationSubmit(isProfile, miscellaneous);
        dispatch(isProfile ? ProfileView() : onboardingView());
        return;

      case 5:
        if (
          resumeValidation(
            resumeData?.resume_file_url,
            setResumeValidationErrors
          )
        ) {
          await resumeSubmit(isProfile, resumeData);
          await otherDocumentSubmit(isProfile, otherDocuments);
          dispatch(isProfile ? ProfileView() : onboardingView());
          return;
        } else {
          return notify("error", "Please fill required field");
        }
      case 6:
        await referenceSumbit(isProfile, referenceinput);
        dispatch(isProfile ? ProfileView() : onboardingView());
        return;
      case 7:
        if (
          jobpreferenceValidateForm(
            jobpreferenceinput,
            setPrefernceValidationErrors
          )
        ) {
          await jobReferencesumbit(isProfile, jobpreferenceinput);
          dispatch(isProfile ? ProfileView() : onboardingView());
          return;
        } else {
          return notify("error", "Please fill required field");
        }
      default:
        break;
    }
  };

  useEffect(() => {
    if (onboardUserList?.personalInformation?.current_step && !isProfile) {
      setStep(onboardUserList?.personalInformation?.current_step);
    }
    if (isProfile) {
      setCompletePercentage(
        onboardUserList?.personalInformation?.profile_completion_percentage
      );
    }
  }, [onboardUserList]);

  useEffect(() => {
    if (isProfile && step !== tabCount) {
      setStep(tabCount);
    }
  }, [tabCount]);

  useEffect(() => {
    if (isProfile) {
      setTabCount(step - 1);
    }
  }, [step]);

  return (
    <Stack gap={2} width={"100%"}>
      {!isProfile && (
        <Stack>
          <StepsIndicator
            currentStep={userData?.user_data?.current_step}
            totalSteps={8}
            step={step}
          />
        </Stack>
      )}

      <Stack>{selectOnboardComponent(step)}</Stack>
      <Box textAlign={"end"}>
        <Button
          variant="contained"
          onClick={() => setStep(step - 1)}
          disabled={step === 1}
          sx={{ color: "white", bgcolor: "primary.main", mr: 1 }}
        >
          Previous
        </Button>
        {step === 8 ? (
          <Button
            variant="contained"
            disabled={disableSubmit}
            onClick={handleOpen}
            sx={{ color: "white" }}
          >
            Submit
          </Button>
        ) : (
          <>
            {" "}
            <Button
              variant="contained"
              onClick={() => nextHandler()}
              sx={{ color: "white", bgcolor: "primary.main", mr: 1 }}
            >
              Next
            </Button>
            <Button
              variant="contained"
              onClick={() => saveAllHandler()}
              sx={{ color: "white", bgcolor: "primary.main" }}
            >
              Save All
            </Button>
          </>
        )}
      </Box>
      <SubmitFormModal
        open={open}
        handleClose={handleClose}
        handleDisclaimerSubmit={handleDisclaimerSubmit}
      />
      <NextAlert
        open={openNextAlert}
        handleClose={setOpenNextAlert}
        step={step}
        saveAllHandler={saveAllHandler}
        setStep={setStep}
        sectionName={unSavedSection}
      />
    </Stack>
  );
};
export default Onboard;
