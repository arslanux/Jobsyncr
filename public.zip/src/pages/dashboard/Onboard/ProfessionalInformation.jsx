import React, { useEffect, useState } from "react";
import Stack from "@mui/material/Stack";
import Typography from "@mui/material/Typography";
import Chip from "@mui/material/Chip";
import Select from "@mui/material/Select";
import MenuItem from "@mui/material/MenuItem";
import TextField from "@mui/material/TextField";
import FormControl from "@mui/material/FormControl";
import Grid from "@mui/material/Grid";
import OnboardFormTemplate from "../../../theme/ui/onboardFormTemplate";
import Upload from "../../../theme/ui/upload";
import CustomTextField from "../../../theme/ui/TextField";
import { DatePicker } from "@mui/x-date-pickers";
import {
  Autocomplete,
  Box,
  Button,
  Divider,
  FormControlLabel,
  FormGroup,
} from "@mui/material";
import Checkbox from "@mui/material/Checkbox";
import notify from "../../../utils/Toast";
import { useDispatch } from "react-redux";
import {
  ProfileView,
  onboardingView,
} from "../../../redux/onboarding/personalInformation/PersonalInfoAction";
import {
  EmployeNameApi,
  ExperienceApi,
  JobTitleApi,
  ProfessionalInfoApi,
  ProfileProfessionalInfoApi,
  RelationApi,
  SkillApi,
  SkillProficiencyApi,
} from "../../../config/ApiHandler";
import dayjs from "dayjs";
import { MdDelete } from "react-icons/md";
import { compareArraysOfObjects } from "../../../utils/utilsfunction";
const EmploymentInfo = ({
  profestionalFormData,
  setProfestionalFormData,
  jobtitleList,
  employerList,
  skillList,
  errors,
  professionalData,
}) => {
  const addItemHandelr = () => {
    setProfestionalFormData({
      ...profestionalFormData,
      employementBackgrounds: [
        ...profestionalFormData?.employementBackgrounds,
        {
          job_title_id: "",
          employer_name: "",
          start_date: null,
          end_date: null,
          designation: "",
          major_accomplishment: "",
          roles_responsibility: "",
          international_experience: 0,
          currently_working: false,
        },
      ],
    });
  };

  const handleFieldChange = (event, fieldName, index, type) => {
    const updatedFormData = {
      ...profestionalFormData,
      employementBackgrounds: profestionalFormData?.employementBackgrounds.map(
        (item, idx) => {
          if (idx === index)
            return {
              ...item,
              [fieldName]:
                type === "date"
                  ? event
                  : type === "custom_select"
                  ? event
                  : type === "checkbox"
                  ? event.target.checked
                  : event.target.value,
            };
          else return item;
        }
      ),
    };
    setProfestionalFormData(updatedFormData);
  };

  const deleteItemHandler = (index) => {
    const updatedFormData =
      profestionalFormData?.employementBackgrounds?.filter((item, idx) => {
        if (idx !== index) return item;
      });
    setProfestionalFormData({
      ...profestionalFormData,
      employementBackgrounds: updatedFormData,
    });
  };

  return (
    <>
      {profestionalFormData?.employementBackgrounds?.map((item, index) => (
        <Grid container spacing={3}>
          <Grid item xs={12} md={6}>
            <FormControl fullWidth>
              {/* <InputLabel id='demo-simple-select-label'>Age</InputLabel> */}
              <CustomTextField
                label="Job Level"
                name="job_title_id"
                value={item?.job_title_id}
                onChange={(e) => handleFieldChange(e, "job_title_id", index)}
                textFieldProps={{
                  select: true,
                  size: "small",
                  // value: 10,
                  InputLabelProps: { shrink: false },
                }}
                required
                errorMessage={errors[index]?.job_title_id}
              >
                {jobtitleList?.map((data) => {
                  return (
                    <MenuItem value={data?.id} key={data?.id}>
                      {data?.name}
                    </MenuItem>
                  );
                })}
              </CustomTextField>
            </FormControl>
          </Grid>
          <Grid item xs={12} md={6}>
            <Stack gap="6px">
              <CustomTextField
                label={"Employer Name"}
                name={"employer_name"}
                value={item?.employer_name}
                onChange={(e) => handleFieldChange(e, "employer_name", index)}
                required
                errorMessage={errors[index]?.employer_name}
              />
              {/* <Typography
                variant="body1"
                sx={{
                  fontWeight: 600,
                  color: "text.secondary",
                }}
              >
                Employer Name
                <span style={{ color: "red" }}>*</span>
              </Typography>
              <Autocomplete
                value={item?.employer_name_id}
                onChange={(event, newValue) => {
                  handleFieldChange(
                    newValue,
                    "employer_name_id",
                    index,
                    "custom_select"
                  );
                }}
                filterOptions={(options, params) => {
                  const { inputValue } = params;
                  const filtered = options.filter((option) =>
                    option?.name
                      ?.toLowerCase()
                      .includes(inputValue?.toLowerCase())
                  );
                  const isExisting = options.some(
                    (option) =>
                      inputValue?.toLowerCase() === option.name?.toLowerCase()
                  );
                  if (inputValue !== "" && !isExisting) {
                    filtered.push({
                      inputValue,
                      name: `Click here to Add "${inputValue}"`,
                    });
                  }
                  return filtered;
                }}
                selectOnFocus
                clearOnBlur
                handleHomeEndKeys
                id="free-solo"
                options={employerList}
                getOptionLabel={(option) => {
                  // Add "xxx" option created dynamically
                  if (option?.inputValue) {
                    return option.inputValue;
                  }
                  // Regular option
                  return option.name;
                }}
                renderOption={(props, option) => (
                  <li
                    {...props}
                    style={{
                      color: !option?.id ? "#4c1b88" : "",
                      fontWeight: !option?.id ? "500" : null,
                      backgroundColor: !option?.id ? "#f5f5f5" : null,
                      border: !option?.id ? "1px solid #ccc" : null,
                      borderRadius: !option?.id ? "8px" : null,
                    }}
                  >
                    {option?.name}
                  </li>
                )}
                size="small"
                freeSolo
                renderInput={(params) => <TextField {...params} />}
              />
              {errors[index]?.employer_name_id && (
                <Typography
                  variant="body2"
                  sx={{
                    fontWeight: 500,
                  }}
                  color={"error"}
                >
                  {errors[index]?.employer_name_id}
                </Typography>
              )} */}
            </Stack>
          </Grid>
          <Grid item xs={12}>
            <CustomTextField
              label={"Job Title"}
              name={"designation"}
              value={item?.designation}
              onChange={(e) => handleFieldChange(e, "designation", index)}
              required
              errorMessage={errors[index]?.designation}
            />
          </Grid>
          <Grid item xs={12}>
            <FormControlLabel
              control={
                <Checkbox
                  name="currently_working"
                  disabled={item?.end_date}
                  checked={item?.currently_working}
                  onChange={(e) =>
                    handleFieldChange(e, "currently_working", index, "checkbox")
                  }
                />
              }
              label="Currently Working"
            />
          </Grid>

          <Grid item xs={12} md={6}>
            <Stack gap="6px">
              <Typography
                variant="body1"
                sx={{
                  fontWeight: 600,
                  color: "text.secondary",
                }}
              >
                {`Start Date`}
                {/* <span style={{ color: "red" }}>*</span> */}
              </Typography>
              <DatePicker
                name="start_date"
                disableFuture
                slotProps={{
                  textField: {
                    size: "small",
                  },
                  field: {
                    clearable: true,
                    onClear: () =>
                      handleFieldChange("", "start_date", index, "date"),
                  },
                }}
                value={item?.start_date}
                onChange={(e) =>
                  handleFieldChange(e?.$d, "start_date", index, "date")
                }
                // value={item?.start_date}
                // onChange={(e) => handleFieldChange(e, "start_date", index)}
              />
              {errors[index]?.start_date && (
                <Typography
                  variant="body2"
                  sx={{
                    fontWeight: 500,
                  }}
                  color={"error"}
                >
                  {errors[index]?.start_date}
                </Typography>
              )}
            </Stack>
          </Grid>

          <Grid item xs={12} md={6}>
            <Stack gap="6px">
              <Typography
                variant="body1"
                sx={{
                  fontWeight: 600,
                  color: "text.secondary",
                }}
              >
                {`End Date`}
                {/* {!item?.currently_working && (
                  <span style={{ color: "red" }}>*</span>
                )} */}
              </Typography>
              <DatePicker
                name="end_date"
                minDate={dayjs(item?.start_date)}
                disableFuture
                slotProps={{
                  textField: {
                    size: "small",
                  },
                  field: {
                    clearable: true,
                    onClear: () =>
                      handleFieldChange("", "end_date", index, "date"),
                  },
                }}
                value={item?.end_date}
                disabled={item?.currently_working}
                onChange={(e) =>
                  handleFieldChange(e?.$d, "end_date", index, "date")
                }
              />
              {errors[index]?.end_date && (
                <Typography
                  variant="body2"
                  sx={{
                    fontWeight: 500,
                  }}
                  color={"error"}
                >
                  {errors[index]?.end_date}
                </Typography>
              )}
            </Stack>
          </Grid>
          <Grid item xs={12}>
            <CustomTextField
              label={"Major Accomplishments"}
              placeholder={
                "Enter major accomplishments that can be shared with potential employers."
              }
              name={"major_accomplishment"}
              value={item?.major_accomplishment}
              onChange={(e) => {
                if (e.target.value.length <= 1000) {
                  handleFieldChange(e, "major_accomplishment", index);
                } else if (e.target.value.length > 1000) {
                  handleFieldChange(
                    {
                      target: {
                        value: e.target.value.substring(0, 1000),
                      },
                    },
                    "major_accomplishment",
                    index
                  );
                }
              }}
              subLabel={`${
                1000 - item?.major_accomplishment?.length
              } chars left`}
              textFieldProps={{
                multiline: true,
                rows: 12,
              }}
              errorMessage={errors[index]?.major_accomplishment}
            />
          </Grid>
          <Grid item xs={12}>
            <CustomTextField
              name={"roles_responsibility"}
              placeholder={
                "Enter roles and responsibilities that can be shared with potential employers."
              }
              label={"Roles and Responsibilities"}
              value={item?.roles_responsibility}
              onChange={(e) => {
                if (e.target.value.length <= 300) {
                  handleFieldChange(e, "roles_responsibility", index);
                } else if (e.target.value.length > 300) {
                  handleFieldChange(
                    {
                      target: {
                        value: e.target.value.substring(0, 300),
                      },
                    },
                    "roles_responsibility",
                    index
                  );
                }
              }}
              subLabel={`${
                300 - item?.roles_responsibility?.length
              } chars left`}
              textFieldProps={{
                multiline: true,
                rows: 6,
              }}
              errorMessage={errors[index]?.roles_responsibility}
            />
          </Grid>
          <Grid item xs={12}>
            <FormGroup
              row
              sx={{
                justifyContent: "space-between",
              }}
            ></FormGroup>
            <FormGroup
              row
              sx={{
                justifyContent: "space-between",
              }}
            ></FormGroup>
            {profestionalFormData?.employementBackgrounds?.length > 1 && (
              <Button
                variant="outlined"
                color="warning"
                onClick={() => deleteItemHandler(index)}
              >
                <MdDelete /> Delete
              </Button>
            )}
            <Divider
              sx={{
                mt: 3,
                mb: 3,
                borderColor: "grey.300",
              }}
            />
          </Grid>
        </Grid>
      ))}
      <Box alignItems={"end"}>
        <Button
          variant="contained"
          color="info"
          onClick={() => addItemHandelr()}
        >
          Add more
        </Button>
      </Box>
    </>
  );
};

const TechInfo = ({
  skillFormData,
  setSkillFormData,
  skillList,
  skillproficiencyList,
  yearList,
  errors,
}) => {
  const handleFieldChange = (event, fieldName, index, type) => {
    const updatedFormData = {
      ...skillFormData,
      skills: skillFormData?.skills.map((item, idx) => {
        if (idx === index)
          return {
            ...item,
            [fieldName]: type === "custom_select" ? event : event.target.value,
          };
        else return item;
      }),
    };
    setSkillFormData(updatedFormData);
  };
  const addItemHandelr = () => {
    setSkillFormData({
      ...skillFormData,
      skills: [
        ...skillFormData?.skills,
        {
          skill_id: null,
          skill_proficiency_id: "",
          experience_id: "",
        },
      ],
    });
  };

  const deleteItemHandler = (index) => {
    const updatedFormData = skillFormData?.skills?.filter((item, idx) => {
      if (idx !== index) return item;
    });
    setSkillFormData({
      ...skillFormData,
      skills: updatedFormData,
    });
  };

  return (
    <>
      {" "}
      {skillFormData?.skills?.map((item, index) => (
        <Grid container spacing={3} my={1} key={item.id}>
          <Grid item xs={12} md={6}>
            <Stack gap="6px">
              <Typography
                variant="body1"
                sx={{
                  fontWeight: 600,
                  color: "text.secondary",
                }}
              >
                Skill
                {/* <span style={{ color: "red" }}>*</span> */}
              </Typography>
              <Autocomplete
                value={item?.skill_id}
                onChange={(event, newValue) => {
                  handleFieldChange(
                    newValue,
                    "skill_id",
                    index,
                    "custom_select"
                  );
                }}
                filterOptions={(options, params) => {
                  const { inputValue } = params;
                  const filtered = options.filter((option) =>
                    option?.name
                      ?.toLowerCase()
                      .includes(inputValue?.toLowerCase())
                  );
                  const isExisting = options.some(
                    (option) =>
                      inputValue?.toLowerCase() === option.name?.toLowerCase()
                  );
                  if (inputValue !== "" && !isExisting) {
                    filtered.push({
                      inputValue,
                      name: `Click here to Add "${inputValue}"`,
                    });
                  }
                  return filtered;
                }}
                selectOnFocus
                clearOnBlur
                handleHomeEndKeys
                id="free-solo"
                options={skillList}
                getOptionLabel={(option) => {
                  // Add "xxx" option created dynamically
                  if (option?.inputValue) {
                    return option.inputValue;
                  }
                  // Regular option
                  return option.name;
                }}
                renderOption={(props, option) => (
                  <li
                    {...props}
                    style={{
                      color: !option?.id ? "#4c1b88" : "",
                      fontWeight: !option?.id ? "500" : null,
                      backgroundColor: !option?.id ? "#f5f5f5" : null,
                      border: !option?.id ? "1px solid #ccc" : null,
                      borderRadius: !option?.id ? "8px" : null,
                    }}
                  >
                    {option?.name}
                  </li>
                )}
                size="small"
                freeSolo
                renderInput={(params) => <TextField {...params} />}
              />
              {errors[index]?.skill_id && (
                <Typography
                  variant="body2"
                  sx={{
                    fontWeight: 500,
                  }}
                  color={"error"}
                >
                  {errors[index]?.skill_id}
                </Typography>
              )}
            </Stack>
          </Grid>
          <Grid item xs={12} md={3}>
            <FormControl fullWidth>
              {/* <InputLabel id='demo-simple-select-label'>Age</InputLabel> */}
              <CustomTextField
                label="Skill Proficiency"
                value={item?.skill_proficiency_id}
                name="skill_proficiency_id"
                onChange={(e) =>
                  handleFieldChange(e, "skill_proficiency_id", index)
                }
                textFieldProps={{
                  select: true,
                  size: "small",
                  // value: 10,

                  InputLabelProps: { shrink: false },
                }}
                // required
                errorMessage={errors[index]?.skill_proficiency_id}
              >
                {skillproficiencyList?.map((data) => {
                  return (
                    <MenuItem value={data?.id} key={data?.id}>
                      {data?.name}
                    </MenuItem>
                  );
                })}
              </CustomTextField>
            </FormControl>
          </Grid>
          <Grid item xs={12} md={3}>
            <FormControl fullWidth>
              {/* <InputLabel id='demo-simple-select-label'>Age</InputLabel> */}
              <CustomTextField
                label="Years of Experience"
                name="experience_id"
                value={item?.experience_id}
                onChange={(e) => handleFieldChange(e, "experience_id", index)}
                textFieldProps={{
                  select: true,
                  size: "small",
                  // value: 10,

                  InputLabelProps: { shrink: false },
                }}
                // required
                errorMessage={errors[index]?.experience_id}
              >
                {yearList?.map((data) => {
                  return (
                    <MenuItem value={data?.id} key={data?.id}>
                      {data?.name}
                    </MenuItem>
                  );
                })}
              </CustomTextField>
            </FormControl>
          </Grid>
          <Grid item xs={12} md={3}>
            {skillFormData?.skills?.length > 1 && (
              <Button
                variant="outlined"
                color="warning"
                onClick={() => deleteItemHandler(index)}
              >
                <MdDelete /> Delete
              </Button>
            )}
          </Grid>
        </Grid>
      ))}
      <Box alignItems={"end"}>
        <Button
          variant="contained"
          color="info"
          onClick={() => addItemHandelr()}
        >
          Add more
        </Button>
      </Box>
    </>
  );
};

const ProfessionalInformationForm = ({
  professionalData,
  personalData,
  employmentValidationErrors,
  setEmploymentValidationErrors,
  profestionalFormData,
  setProfestionalFormData,
  validateEmploymentBackground,
  skillFormData,
  setSkillFormData,
  validateSkillForm,
  skillValidationErrors,
  setSkillValidationErrors,
  isProfile = false,
  setProfesstionalOldData,
  setSkillOldData,
}) => {
  const dispatch = useDispatch();

  const [jobtitleList, setJobtitleList] = useState([]);
  const [employerList, setemployerList] = useState([]);
  const [skillList, setskillList] = useState([]);
  const [yearList, setYearList] = useState([]);
  const [skillproficiencyList, setskillproficiencyList] = useState([]);

  const handleprofessionalSubmit = async (e) => {
    e.preventDefault();
    // const isValid = validateEmploymentBackground(
    //   profestionalFormData?.employementBackgrounds,
    //   setEmploymentValidationErrors
    // );
    const professtionalOldData = professionalData?.employementBackgrounds?.map(
      (item) => {
        return {
          job_title_id: item?.job_title_id,
          employer_name: item?.employer_name,
          start_date: dayjs(item?.start_date),
          end_date: item?.end_date ? dayjs(item?.end_date) : null,
          major_accomplishment: item?.major_accomplishment,
          roles_responsibility: item?.roles_responsibility,
          designation: item?.designation,
          // international_experience: item?.international_experience,
          currently_working: item?.currently_working,
        };
      }
    );
    const professtionalNewData =
      profestionalFormData?.employementBackgrounds?.map((item) => {
        let data = {
          job_title_id: item?.job_title_id,
          employer_name: item?.employer_name,
          start_date: item?.start_date,
          end_date: item?.end_date,
          major_accomplishment: item?.major_accomplishment,
          roles_responsibility: item?.roles_responsibility,
          designation: item?.designation,
          // international_experience: item?.international_experience,
          currently_working: item?.currently_working,
        };
        // if (item?.employer_name_id?.id) {
        //   data.employer_name_id = item?.employer_name_id?.id;
        // } else {
        //   data.employer_name = item?.employer_name_id?.inputValue;
        // }
        return data;
      });

    // const areEqual = compareArraysOfObjects(
    //   professtionalOldData,
    //   professtionalNewData
    // );

    // if (areEqual) {
    //   notify("info", "No changes found");
    // } else {
    //   if (isValid) {
    const updateData = {
      section_type: "employement_background",
      employementBackgrounds: professtionalNewData,
    };

    try {
      const res = isProfile
        ? await ProfileProfessionalInfoApi(updateData)
        : await ProfessionalInfoApi(updateData);
      if (res?.data?.status === true) {
        notify("success", res?.data?.message);
        dispatch(isProfile ? ProfileView() : onboardingView());
      } else {
        notify("error", res?.data?.message);
      }
    } catch (error) {
      notify("error", "Something went wrong!");
      // Handle the error if needed
    }
    // } else {
    //   notify("error", "Please enter required data");
    // }
    // }
  };

  useEffect(() => {
    window.scrollTo(0, 0);
  }, []);
  const handleSkillsSubmit = async (e) => {
    e.preventDefault();
    const isValid = validateSkillForm(
      skillFormData?.skills,
      setSkillValidationErrors
    );
    const skillOldData = professionalData?.skills?.map((item) => {
      return {
        skill_id: item?.Skill?.id,
        skill_proficiency_id: item?.skill_proficiency_id,
        experience_id: item?.experience_id,
      };
    });
    const skillNewData = skillFormData?.skills?.map((item) => {
      let data = {
        skill_proficiency_id: item?.skill_proficiency_id,
        experience_id: item?.experience_id,
      };
      if (item?.skill_id?.id) {
        data.skill_id = item?.skill_id?.id;
      } else {
        data.skill_name = item?.skill_id?.inputValue;
      }
      return data;
    });
    const areEqual = compareArraysOfObjects(skillOldData, skillNewData);
    if (areEqual) {
      notify("info", "No changes found");
    } else {
      // if (isValid) {
      const updateData = {
        section_type: "skills",
        skills: skillFormData?.skills?.map((item) => {
          let data = {
            skill_proficiency_id: item?.skill_proficiency_id,
            experience_id: item?.experience_id,
          };
          if (item?.skill_id?.id) {
            data.skill_id = item?.skill_id?.id;
          } else {
            data.skill_name = item?.skill_id?.inputValue;
          }
          return data;
        }),
      };

      try {
        const res = isProfile
          ? await ProfileProfessionalInfoApi(updateData)
          : await ProfessionalInfoApi(updateData);
        if (res?.data?.status === true) {
          notify("success", res?.data?.message);
          dispatch(isProfile ? ProfileView() : onboardingView());
        } else {
          notify("error", res?.data?.message);
        }
      } catch (error) {
        notify("error", "Something went wrong");
        // Handle the error if needed
      }
      // } else {
      //   notify("error", "Please enter required data");
      // }
    }
  };

  useEffect(() => {
    if (professionalData?.employementBackgrounds?.length > 0) {
      const data = professionalData?.employementBackgrounds?.map((item) => {
        return {
          job_title_id: item?.job_title_id,
          employer_name: item?.Employer_Name?.name,
          start_date: dayjs(item?.start_date),
          end_date: item?.end_date ? dayjs(item?.end_date) : null,
          major_accomplishment: item?.major_accomplishment,
          roles_responsibility: item?.roles_responsibility,
          designation: item?.designation,
          international_experience: item?.international_experience,
          currently_working: item?.currently_working,
        };
      });
      setProfestionalFormData({
        section_type: "employement_background",
        employementBackgrounds: data,
      });
      setProfesstionalOldData(data);
    }
  }, [professionalData]);

  useEffect(() => {
    if (professionalData?.skills?.length > 0) {
      const data = professionalData?.skills?.map((item) => {
        return {
          skill_id: item?.Skill,
          skill_proficiency_id: item?.skill_proficiency_id,
          experience_id: item?.experience_id,
        };
      });
      setSkillFormData({
        section_type: "skills",
        skills: data,
      });
      setSkillOldData(data);
    }
  }, [professionalData]);

  const getJobList = async () => {
    try {
      const res = await JobTitleApi();
      const jobtitleList = res?.data?.data?.jobTitles;
      setJobtitleList(jobtitleList);
    } catch (error) {
      // Handle the error if needed
    }
  };

  const getEmplyeNameList = async () => {
    try {
      const res = await EmployeNameApi();
      const EmplyeNameList = res?.data?.data?.employerNames;
      setemployerList(EmplyeNameList);
    } catch (error) {
      // Handle the error if needed
    }
  };

  const getSkillList = async () => {
    try {
      const res = await SkillApi();
      const skilldataList = res?.data?.data?.skills;
      setskillList(skilldataList);
    } catch (error) {
      // Handle the error if needed
    }
  };

  const getSkillProficiencyList = async () => {
    try {
      const res = await SkillProficiencyApi();
      const skillproficiencydataList = res?.data?.data?.skillProficiencies;
      setskillproficiencyList(skillproficiencydataList);
    } catch (error) {
      // Handle the error if needed
    }
  };

  const getExpericencList = async () => {
    try {
      const res = await ExperienceApi();
      const yeardataList = res?.data?.data?.yearOfExperiences;
      setYearList(yeardataList);
    } catch (error) {
      // Handle the error if needed
    }
  };

  useEffect(() => {
    getExpericencList();

    getJobList();
    getSkillProficiencyList();
  }, []);

  useEffect(() => {
    getEmplyeNameList();
    getSkillList();
  }, [professionalData]);

  return (
    <Stack gap={2} mt={2}>
      {!isProfile && (
        <Stack
          direction={"row"}
          alignItems={"center"}
          justifyContent={"space-between"}
        >
          <Stack direction={"row"} gap={2} alignItems={"center"}>
            <Typography
              variant="h5"
              sx={{
                fontWeight: 600,
                fontSize: "28px",
              }}
            >
              Professional Information
            </Typography>
            <Chip
              label={`${
                personalData?.profile_completion_percentage != undefined
                  ? personalData?.profile_completion_percentage
                  : 0
              }% Completed`}
              size="small"
              sx={{
                backgroundColor: "success.light",
                color: "success.main",
                fontWeight: 600,
              }}
            />
            <Chip
              label={`It will take 3 minutes to complete this step`}
              size="small"
              sx={{
                backgroundColor: "success.main",
                color: "success.light",
                fontWeight: 600,
              }}
            />
          </Stack>
          <Typography variant="body2">* = Required</Typography>
        </Stack>
      )}
      <Stack gap={2}>
        <OnboardFormTemplate
          formTitle={"Employment Background"}
          formSubtitle={"Present or current job will be first and subsequently next jobs, Up to the last 15 years"}
          form={
            <EmploymentInfo
              profestionalFormData={profestionalFormData}
              setProfestionalFormData={setProfestionalFormData}
              employmentValidationErrors={employmentValidationErrors}
              jobtitleList={jobtitleList}
              employerList={employerList}
              errors={employmentValidationErrors}
            />
          }
          onsubmit={handleprofessionalSubmit}
        />
        <OnboardFormTemplate
          formTitle={"Background and Skills"}
          form={
            <TechInfo
              skillFormData={skillFormData}
              setSkillFormData={setSkillFormData}
              skillList={skillList}
              skillproficiencyList={skillproficiencyList}
              yearList={yearList}
              errors={skillValidationErrors}
            />
          }
          onsubmit={handleSkillsSubmit}
        />
      </Stack>
    </Stack>
  );
};

export default ProfessionalInformationForm;
