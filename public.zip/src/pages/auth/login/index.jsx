import React from "react";
import Button from "@mui/material/Button";
import FormControlLabel from "@mui/material/FormControlLabel";
import Checkbox from "@mui/material/Checkbox";
import Link from "@mui/material/Link";
import Box from "@mui/material/Box";
import Grid from "@mui/material/Grid";
import Typography from "@mui/material/Typography";
import InputLabel from "../../../theme/overrides/InputLabel";
import FormControl from "@mui/material/FormControl";
import Stack from "@mui/material/Stack";
import CustomTextField from "../../../theme/ui/TextField";
import Divider from "@mui/material/Divider";
import IconButton from "@mui/material/IconButton";
import { useNavigate } from "react-router-dom";
import { useDispatch, useSelector } from "react-redux";
import { login } from "../../../redux/auth/AuthAction";
import { Formik } from "formik";
import * as yup from "yup";
import notify from "../../../utils/Toast";
import { useGoogleLogin } from "@react-oauth/google";
import { googleLoginApi, microsoftLoginApi } from "../../../config/ApiHandler";
import { useMsal } from "@azure/msal-react";
import "../../../components/auth/login.css";
import PersonIcon from "@mui/icons-material/Person";


const Login = () => {
  const initialValues = {
    email: "",
    password: "",
    remember_me: false, // Added the remember_me checkbox to initial values
  };

  const isLoading = useSelector((state) => state.auth.status);

  const dispatch = useDispatch();
  const navigate = useNavigate();
  const { instance, inProgress } = useMsal();

  const validationSchema = yup.object({
    email: yup
      .string("Enter your email")
      .email("Enter a valid email")
      .required("Email is required"),
    password: yup
      .string("Enter your password")
      .min(5, "Password should be of minimum 5 characters length")
      .required("Password is required"),
  });

  const submitHandler = (values) => {
    const { email, password, remember_me } = values;
    dispatch(login({ email, password, remember_me }))
      .then((response) => {
        if (response.payload.status === true) {
          notify("success", response.payload.message);
          localStorage.setItem(
            "login",
            JSON.stringify(response?.payload?.data)
          );
          if (!response?.payload?.data?.user_data?.email_verified) {
            localStorage.setItem("signup_email", email);
            navigate(`/auth/otp-verification?email=${email}`);
          } else navigate("/dashboard/zzdashboard");
        } else {
          notify("error", response.payload.message);
        }
      })
      .catch((e) => {
        notify(
          "error",
          e.response?.data?.message
            ? e.response?.data?.message
            : "Something went wrong !"
        );
      });
  };

  const googleLoginHandler = useGoogleLogin({
    onSuccess: async (tokenResponse) => {
      const response = await googleLoginApi({
        google_token: tokenResponse.access_token,
      }).then((res) => res.data);
      if (response.status) {
        notify("success", response.message);
        localStorage.setItem("login", JSON.stringify(response?.data));
        if (response?.data?.user_data?.is_profile_completed)
          navigate("/dashboard/home");
        else navigate("/employee/onboard");
      }
    },
    onReject: () => {
      notify("error", "Failed,Please try again !");
    },
  });

  const microsoftLoginHandler = async () => {
    try {
      const res = await instance.loginPopup({
        scopes: ["user.read"],
      });

      if (res?.accessToken) {
        const result = await microsoftLoginApi({
          microsoft_token: res?.accessToken,
        });
        if (result?.data?.status) {
          notify("success", result?.data?.message);
          localStorage.setItem("login", JSON.stringify(result?.data?.data));

          if (result?.data?.data?.user_data?.is_profile_completed)
            navigate("/dashboard/home");
          else {
            navigate("/employee/onboard");
          }
        }
      }
    } catch (e) {
      notify("error", "Failed,Please try again !");
    }
  };

  return (
    <Box
      sx={{
        display: "flex",
        flexDirection: "column",
        alignItems: "flex-start",
        gap: 2,
      }}
    >
      <Stack
        direction="column"
        gap={0}
        sx={{
          mb: 1,
        }}
      >
        <Typography variant="h4" className="login_title" sx={{ mb: 0 }}>
          Log in to your account
        </Typography>

        <Typography variant="body1" className="login_subtitle" sx={{ mt: 1, textAlign: "left" }}>
          {`Don't have an account? `}
          <Link href="/auth/signup" variant="body1" style={{ color: "#C31F5D", fontWeight: "medium" }}>
            Register
          </Link>
        </Typography>
      </Stack>
      <Formik
        initialValues={initialValues}
        onSubmit={submitHandler}
        validationSchema={validationSchema}
      >
        {({
          values,
          errors,
          touched,
          handleChange,
          handleBlur,
          handleSubmit,
          isSubmitting,
        }) => (
          <form
            onSubmit={(e) => {
              e.preventDefault();
              handleSubmit(e);
            }}
          >
            <Box sx={{ width: "100%" }}>
              <Stack sx={{ width: { xs: "100%", md: "120%" }, }} gap={2}>
                <CustomTextField
                  margin="normal"
                  required
                  fullWidth={true}
                  label="Email ID"
                  placeholder={`Email`}
                  autoFocus
                  autoComplete="email"
                  textFieldProps={{
                    type: "email",
                    name: "email",
                    onChange: handleChange,
                    onBlur: handleBlur,
                    value: values.email,
                  }}
                  errorMessage={errors.email && touched.email && errors.email}
                />
                <CustomTextField
                  margin="normal"
                  required
                  fullWidth
                  label="Password"
                  placeholder={`Password`}
                  textFieldProps={{
                    type: "password",
                    name: "password",
                    onChange: handleChange,
                    onBlur: handleBlur,
                    value: values.password,
                  }}
                  errorMessage={
                    errors.password && touched.password && errors.password
                  }

                />

                <Grid container alignItems={"center"}>
                  <Grid item xs>
                    <FormControlLabel
                      control={
                        <Checkbox
                          checked={values.remember_me}
                          onChange={handleChange}
                          name="remember_me"
                          color="primary"
                        />
                      }
                      label="Remember me"
                    />
                  </Grid>
                  <Grid item>
                    <Link href="/auth/forgot-password" variant="body2" sx={{ color: "#C31F5D" }}>
                      {"Forgot Password?"}
                    </Link>
                  </Grid>
                </Grid>
                <Button
                  type="submit"
                  fullWidth
                  variant="contained" sx={{ height: "52px" }} className="login_button"
                  disabled={isLoading}
                >
                  Log in
                </Button>
                <Divider>
                  <Typography variant="body1">or log in with</Typography>
                </Divider>
                <Stack
                  direction="row"
                  gap={2}
                  alignItems={"center"}
                  justifyContent={"center"}
                >
                  <IconButton variant="outlined" onClick={googleLoginHandler}>
                    <img
                      src="https://img.icons8.com/color/48/000000/google-logo.png"
                      alt="google"
                      style={{ width: "24px", height: "24px" }}
                    />
                  </IconButton>
                  <IconButton
                    variant="outlined"
                    color="error"
                    onClick={microsoftLoginHandler}
                  >
                    <img
                      src="https://img.icons8.com/color/48/000000/microsoft.png"
                      alt="facebook"
                      style={{ width: "24px", height: "24px" }}
                    />
                  </IconButton>
                </Stack>

                <Stack justifyContent={"center"} alignItems={"center"} mt={-1}>
                  <Typography variant="body1">
                    {`Zerozilla Admin. `}
                    <Link
                      href="https://adminjobs.gatewayinternational.org/auth/login"
                      target="_blank"
                      variant="body2"
                    >
                      Log In
                    </Link>
                  </Typography>
                </Stack>
                <Stack justifyContent={"center"} alignItems={"center"} mt={-1}>
                  <Typography variant="body1">
                    <Link
                      href="/terms-and-conditions"
                      variant="body2"
                    >
                      Terms and Conditions
                    </Link>
                  </Typography>
                </Stack>
              </Stack>
            </Box>
          </form>
        )}
      </Formik>
    </Box >
  );
};

export default Login;
